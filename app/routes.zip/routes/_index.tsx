import LevaniPortfolio from "../components/LevaniPortfolio";
export default function Index() {
  return <LevaniPortfolio />;
}